from aiogram.types import (ReplyKeyboardMarkup, KeyboardButton,
                           InlineKeyboardButton, InlineKeyboardMarkup)
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
import app.database.requests as rq
from urllib.parse import quote

async def inline_chanels(tg_id):
    keyboard = InlineKeyboardBuilder()
    chanels = await rq.get_chanels(tg_id)
    for chanel in chanels:
        keyboard.add(InlineKeyboardButton(text=f"✏ {chanel}", callback_data=f"query_{chanel}"))
    keyboard.add(InlineKeyboardButton(text="Главное меню", callback_data="pre_start"))
    return keyboard.adjust(1).as_markup()


def main_button():
    main_button = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Главное меню", callback_data="pre_start")]],
    )
    return main_button

def ed_or_del(chanel):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Посмотреть список каналов', callback_data='list_chanel')],
        [InlineKeyboardButton(text='Изменить', callback_data=f'edit_chanel_{chanel}'),
         InlineKeyboardButton(text='Удалить', callback_data=f'delete_chanel_{chanel}')]
    ])
    return keyboard


def main_keyboard_1():
    main_keyboard_1= InlineKeyboardMarkup(inline_keyboard=[ 
            [InlineKeyboardButton(text="Составить комментарий ▶️", callback_data='test')]

    ])
    return main_keyboard_1

def main_keyboard_2(tg_id):
    main_keyboard_2= InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Ссылка на ваш канал 🔗", callback_data='add_link')], #+
            [InlineKeyboardButton(text="Описание вашего канала✏️", callback_data='description_chanel')], #+
            [InlineKeyboardButton(text="Добавить каналы в список ☑️", callback_data='add_chanels')], #+
            [InlineKeyboardButton(text="Мои каналы для мониторинга📺", callback_data='list_chanel')], #+
            [InlineKeyboardButton(text="Описание профиля 🧑‍💻", callback_data='description_profile')],
            [InlineKeyboardButton(text="Далее ▶️", callback_data='next')]
    ])
    return main_keyboard_2

def start():
    start = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Начинаем', callback_data='start')]])
    return start

def style():
    style = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Стиль Сета Година', callback_data='go_style')],
         [InlineKeyboardButton(text='Стиль Гая Кавасаки', callback_data='go_style')],
         [InlineKeyboardButton(text='Стиль Илона Маска', callback_data='go_style')]])
    return style



def get_subscription_keyboard():
    keyboard = InlineKeyboardBuilder()

    telegram_username = "Alexcharevich"  # Без "@"
    message_text = "Привет! Хочу купить подписку! 🔥"

    # Кодируем текст в URL (на случай пробелов и спецсимволов)
    encoded_message = quote(message_text)

    # Кнопка для покупки подписки (сразу открывает диалог в Telegram)
    keyboard.button(
        text="💳 Купить подписку [Напрямую у разраба]",
        url=f"tg://resolve?domain={telegram_username}&text={encoded_message}"
    )

    # Кнопка для поддержки
    keyboard.button(
        text="📩 Написать в поддержку",
        url=f"tg://resolve?domain={telegram_username}"
    )
    
    
    keyboard.button(
        text="🆗 Админ подтвердил оплату",
        callback_data="all_ready_pay"
    )

    # Главное меню
    keyboard.button(text="🏠 Главное меню", callback_data="pre_start")

    keyboard.adjust(1)  # Все кнопки в один ряд

    return keyboard.as_markup()


def feedback():
    feedback = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Показать отзывы', callback_data='otziv')],
        [InlineKeyboardButton(text="Главное меню", callback_data="pre_start")]])
    return feedback



def subscription_offer_keyboard():
    subscription_offer_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Каталог подписок ', callback_data='by_subscriptions')],
         [InlineKeyboardButton(text='Отзывы', callback_data='feedback')],
         [InlineKeyboardButton(text="Главное меню", callback_data="pre_start")]])
    return subscription_offer_keyboard


def neiro_chanels():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text='Достаточно')]],
        resize_keyboard=True
    )
    return keyboard


def go():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text='Перейти к профилю')]],
        resize_keyboard=True
    )
    return keyboard

def edit_des_chanel():
    edit_des_chane = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Редактировать описание ', callback_data='edit_chanel_description')],
         [InlineKeyboardButton(text='Главнe меню', callback_data='pre_start')]])
    return edit_des_chane


def edit_des_profile():
    edit_des_prof = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Редактировать описание ', callback_data='edit_profile_description')],
         [InlineKeyboardButton(text='Главнe меню', callback_data='pre_start')]])
    return edit_des_prof


def period_com():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='сразу')],
            [KeyboardButton(text='50-100')],
            [KeyboardButton(text='100-200')],
            [KeyboardButton(text='200-500')]
        ],
        resize_keyboard=True
    )
    return keyboard

def sleep_bot():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='без ограничений')],
            [KeyboardButton(text='1')],
            [KeyboardButton(text='2')],
            [KeyboardButton(text='3')],
            [KeyboardButton(text='4')],
            [KeyboardButton(text='5')],
            [KeyboardButton(text='6')]
        ],
        resize_keyboard=True
    )
    return keyboard

def sleep_sleep():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='Не уходить в сон')],
            [KeyboardButton(text='60 минут')],
            [KeyboardButton(text='120 минут')],
            [KeyboardButton(text='180 минут')],
            [KeyboardButton(text='240 минут')]
        ],
        resize_keyboard=True
    )
    return keyboard

def launch():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='Запустить бота! 🚀')]
        ],
        resize_keyboard=True
    )
    return keyboard


def compile():
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text='Запустить бота! 🚀')]
        ],
        resize_keyboard=True
    )
    return keyboard