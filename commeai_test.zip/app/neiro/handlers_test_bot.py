import random
import asyncio
from aiogram import F, Router
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command
from g4f.client import Client
import app.keyboards as kb
import app.database.requests as rq
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
import g4f 

# Инициализация маршрутизатора
nero_test_router = Router()

# Класс состояний для FSM
class Rega(StatesGroup):
    waait = State()

# Функция для генерации промта для нейросети
def generate_prompt(post_text):
    return (
        f"Ты обычный пользователь Telegram, который пишет живые комментарии. "
        f"Реагируй неформально, с сетевым сленгом, иронией, но без перегибов. "
        f"Твой комментарий должен выглядеть так, будто его написала девушка. "
        f"Максимум одно-два предложения, без вопросов и выводов. Самое главно что бы комментарий выглядел так как будто его написал человек"
        f"---\n{post_text}\n---\nНапиши только текст комментария. Если пост содержит что то связанное с наркотой, оружием,политикой, насилием, войной, Украиной то ты просто ставишь три точки и все! "
    )

# Обработчик команды /run_bot
@nero_test_router.callback_query(F.data.startswith("test"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer(
        "<b>Здесь вы можете опробовать пример того, как будет выглядеть комментарий на пост, который будет выложен в указанных вами каналах.</b>\n\n"
        "Так как у вас подписка 'старт' вам не доступен весь функционал бота ,вы сможете <i>только</i> увидеть <b> комментарий который был бы выложен под пост.</b>\n\n"
        "Просто <u>перешлите сюда</u> любой пост, и мы составим комментарий.",
        parse_mode="HTML", reply_markup=kb.main_button()
    )
    await state.set_state(Rega.waait)

# Обработчик сообщений

@nero_test_router.message(Rega.waait)
async def process_link(message: Message, state: FSMContext):
    user = await rq.get_user_data(message.from_user.id)

    if not user:
        await message.answer("Пользователь не найден в базе данных. Убедитесь, что вы зарегистрированы.")
        return
    
    description_chanel = user.my_chanel_description if hasattr(user, 'my_chanel_description') else None
    
    if not description_chanel:
        await message.answer("Вы не добавили описание канала, вернитесь и добавьте.")
        return
    
    # Проверяем, если это пересланное сообщение
    if message.forward_from or message.forward_from_chat:
        # Если сообщение переслано и оно содержит текст
        if message.text:
            post_test = message.text
        # Проверяем, есть ли текст в caption, если это медиа
        elif message.caption:
            post_test = message.caption
        else:
            await message.answer("Пересланное сообщение не содержит текста.")
            return
    else:
        # Если не переслано, просто берем текст
        post_test = message.text

    if not post_test:
        await message.answer("Пожалуйста, отправьте текстовое сообщение или пересылайте пост с текстом.")
        return

    if len(post_test) > 1500:
        await message.answer("Слишком большой текст, ограничение стоит 1500 символов.")
        return
    
    prompt = generate_prompt(post_test)

    try:
        response = await g4f.ChatCompletion.create_async(
            model="deepseek-v3",
            messages=[
                {"role": "system", "content": "You are a business man."},
                {"role": "user", "content": prompt}
            ]
        )
        
        print("Ответ GPT:", response)

        comment = response if isinstance(response, str) else "Произошла ошибка: неверный формат ответа."

        # Отправляем комментарий
        await message.answer(f'Пример комментария: {comment}', reply_markup=kb.main_button())

        # Предложение попробовать ещё или купить подписку
        await message.answer(
            "🎉 <b>Хотите больше подписчиков и активной аудитории?</b>\n\n"
            "Вы уже попробовали 20% от функционала нашего нейрокомментинга, а теперь представьте, что он работает 24/7!\n\n"
            "🚀 <b>Оформите подписку и получите:</b>\n"
            "🔹 Подключение <b>нескольких каналов</b> для мониторинга постов\n"
            "🔹 Комментарии под постами в указанных вами каналах <b>без вашего участия!</b>\n"
            "🔹 <b>Гибкие настройки</b> стиля и тематики комментариев\n"
            "🔹 Повышение охвата и продаж, а так же роста подписчиков\n\n"
            "🔥 <b>Экономьте на рекламе!</b> Нейрокомментинг привлекает аудиторию в 10 раз дешевле, чем реклама.\n\n"
            "💳 <b>Попробуйте прямо сейчас!</b> Нажмите кнопку ниже, чтобы выбрать подписку, посмотреть отзывы или вернуться:",
            parse_mode="HTML",
            reply_markup=kb.subscription_offer_keyboard()
        )


    except Exception as e:
        await message.answer(f"Произошла ошибка при получении комментария: {e}")