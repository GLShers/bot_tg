from aiogram import F,Router
from aiogram.types import Message, CallbackQuery , FSInputFile  
from aiogram.filters import CommandStart, Command
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
import asyncio
from datetime import datetime, timedelta
from aiogram.exceptions import TelegramBadRequest
import os
from aiogram.types import FSInputFile 


import app.database.requests as rq
import app.keyboards as kb

class Reg(StatesGroup):
    home = State()
    name = State()
    phone = State()
    waiting_link = State()
    waiting_add = State()

class EditChannelState(StatesGroup):
    waiting_for_new_link = State()
    chanel_wait = State()
    des_chanel_wait = State()
    des_profile_wait = State()
    waiting_tg_id = State()
    des_profile_wait = State()
    waiting_for_description = State()

    
class Step(StatesGroup):
    des_profile = State()
    des_chanel = State()   
    link = State()
    wait_style = State()
    style = State()
    all_ready = State()
    add_chanels = State()
    slep = State()
    period_com = State()
    sleep_bot = State()
    sleep_sleep = State()
    launch_bot = State()




    

    
router=Router()




#⁡⁢⁣⁢----------------------------------------------------------------------------------------СТАРТОВЫЕ-КОМАНДЫ-------------------------------------------------------------------------------------------------⁡
@router.message(CommandStart())
async def com_start(message: Message, state: FSMContext):
    # Получаем путь к видео
    current_dir = os.path.dirname(os.path.abspath(__file__))
    video_path = os.path.join(current_dir, "..", "video", "first.mp4")

    # Проверяем, существует ли файл
    if os.path.exists(video_path):
        # Отправляем видео с использованием FSInputFile
        video_msg = await message.answer_video(
            video=FSInputFile(video_path),  # Используем FSInputFile
            caption="<b>Что такое Нейрокомментинг:</b>",
            parse_mode="HTML"
        )
        # Сохраняем ID сообщения с видео в состоянии
        await state.update_data(video_message_id=video_msg.message_id)
    else:
        await message.answer("Видео не найдено. Пожалуйста, проверьте путь к файлу.")

    await message.answer(
        "<b>👋 Добро пожаловать! 🚀</b>\n\n"
        "Хотите больше охвата, подписчиков и клиентов без лишних затрат? Наш бот делает это за вас!\n\n"
        "✅ <b>Автоматический нейрокомментинг</b> — анализирует посты и оставляет умные комментарии 24/7.\n"
        "✅ <b>Живые подписчики</b> — люди переходят на ваш канал и подписываются.\n"
        "✅ <b>В 10 раз дешевле рекламы</b> — комментарии работают дольше и привлекают больше аудитории.\n\n"
        "🔥 <b>Подписка старт уже активина, скорее пробуйте!</b>\n"
        "Нажмите 'Начинаем', настройте параметры за 2 минуты и получите первых подписчиков уже сегодня!\n\n"
        "🌟 <b>Преимущества:</b>\n"
        "• <b>Не нужно покупать Telegram аккаунты, прокси и тому подобное</b> — всё уже сделано за вас.\n"
        "• <b>Софт работает на сервере</b> — нет необходимости держать ваш ПК всегда включенным.\n"
        "• <b>Не нужно настраивать каждую мелочь</b> — только основные параметры.\n"
        "• <b>Не нужно скачивать никакого софта на свой ПК</b> — всё доступно через бота.\n\n"
        "🎥 <b>Посмотрите видео, чтобы узнать как это работает:</b>",
        parse_mode="HTML",
        reply_markup=kb.start()
    )

    await rq.set_user(message.from_user.id)
    await rq.set_login(message.from_user.id, message.from_user.username)
    
@router.callback_query(F.data.startswith("pre_start"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    # Получаем данные из состояния
    data = await state.get_data()
    video_message_id = data.get("video_message_id")

    # Удаляем сообщение с видео, если оно существует
    if video_message_id:
        try:
            await callback.bot.delete_message(callback.message.chat.id, video_message_id)
        except Exception as e:
            print(f"Ошибка при удалении видео: {e}")

    await state.clear()
    user = await rq.get_user_data(callback.from_user.id)
    sub = user.sub_id

    await callback.message.edit_text("Главное меню бота. Здесь вы можете редактировать свой профиль",
                                    parse_mode="HTML",
                                    reply_markup=kb.main_keyboard_2(callback.from_user.id))

 #⁡⁢⁣⁢----------------------------------------------------------------------------------------------------------------------------------------------------------------------------⁡
@router.callback_query(F.data.startswith("start"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    # Получаем данные из состояния
    data = await state.get_data()
    video_message_id = data.get("video_message_id")

    # Удаляем сообщение с видео, если оно существует
    

    await state.clear()
    user = await rq.get_user_data(callback.from_user.id)

    if user.link and user.my_chanel_description and user.my_profile_description:
        await callback.message.answer("Ваш профиль уже настроен", reply_markup=kb.go())
        await state.set_state(Step.all_ready)
        return

    # Удаляем предыдущее сообщение (приветствие)
    

    # Отправляем новое сообщение
    msg = await callback.message.answer("<b>Введите ссылку на свой канал. </b>\n\n"
                                        " В процессе нейрокомментинга люди будут переходить именно на него!", parse_mode="HTML")
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения для удаления
    await state.set_state(Step.link)
    
    
    
@router.message(Step.link) # Обработчик ввода ссылки на канал
async def process_link(message: Message, state: FSMContext):
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    
    # Удаляем предыдущее сообщение
    if last_message_id:
        await message.bot.delete_message(message.chat.id, last_message_id)
    
    new_link = message.text

    if len(new_link) > 35:
        msg = await message.answer("Ошибка! Ссылка не должна превышать 35 символов. Попробуйте снова.")
        await state.update_data(last_message_id=msg.message_id)
        return
    
    if not new_link.startswith("t.me/"):
        msg = await message.answer("Ошибка! Ссылка на канал должна начинаться с t.me/. Попробуйте снова.")
        await state.update_data(last_message_id=msg.message_id)
        return

    succeful_add = await rq.add_link(message.from_user.id, new_link)

    if succeful_add:
        msg = await message.answer("✅ Ваша ссылка успешно добавлена!")
    else:
        msg = await message.answer("⚠️ Данная ссылка уже была добавлена ранее.")
    
    await state.update_data(last_message_id=msg.message_id)
    photo_path = os.path.join(os.getcwd(), "photo", "des_chanel.jpg")
        
        # Проверяем, существует ли файл
    if not os.path.exists(photo_path):
        await message.answer("Фото не найдено! Пожалуйста, проверьте путь к файлу.")
        return
        
        # Используем FSInputFile для отправки локального файла
    photo = FSInputFile(photo_path)
    photo_msg = await message.answer_photo(photo=photo)
        
    msg = await message.answer(
        "<b>В этом разделе Вам нужно описать свой канал.</b>\n\n"
        "Необходимо для генерации комментариев в вашем стиле.",
        parse_mode="HTML"
    )
    await state.update_data(last_message_id=msg.message_id)
    await state.update_data(last_photo_id=photo_msg.message_id)
    await state.set_state(Step.des_chanel)



@router.message(Step.des_chanel)  # Обработчик ввода описания канала
async def process_new_des_chanel(message: Message, state: FSMContext):
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    last_photo_id = data.get("last_photo_id")  # ID последнего отправленного фото
    
    # Удаляем предыдущее сообщение и фото (если они есть)
    if last_message_id:
        await message.bot.delete_message(message.chat.id, last_message_id)
    if last_photo_id:
        await message.bot.delete_message(message.chat.id, last_photo_id)
    
    new_des_chanel = message.text.strip() 
    words_count = len(new_des_chanel.split())  
    
    if len(message.text) > 700:
        msg = await message.answer("Слишком много символов(")
        await state.update_data(last_message_id=msg.message_id)
    else:
        existing_description = await rq.update_chanel_description(message.from_user.id, new_des_chanel)
        msg = await message.answer(f"✅ Успешно добавил в базу твое описание", parse_mode="HTML")
        
        await state.update_data(last_message_id=msg.message_id)
        
        msg = await message.answer(
            "<b>Опиши профиль для бота.</b>\n\n 70 символов + ссылка на ваш канал. Пример как на фото ниже\n"
            "Оно разместится в биографии аккаунта, от имени которого бот будет оставлять комментарии.\n\n",
            parse_mode="HTML"
        )
        
        photo_path = os.path.join(os.getcwd(), "photo", "des_profile.jpg")
        
        # Проверяем, существует ли файл
        if not os.path.exists(photo_path):
            await message.answer("Фото не найдено! Пожалуйста, проверьте путь к файлу.")
            return
        
        # Используем FSInputFile для отправки локального файла
        photo = FSInputFile(photo_path)
        photo_msg = await message.answer_photo(photo=photo)
        
        # Сохраняем ID сообщения с фото
        await state.update_data(last_photo_id=photo_msg.message_id)
        await state.set_state(Step.des_profile)

@router.message(Step.des_profile)  # Обработчик ввода описания профиля
async def process_new_des_profile(message: Message, state: FSMContext):
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    last_photo_id = data.get("last_photo_id")  # ID последнего отправленного фото
    
    # Удаляем предыдущее сообщение и фото (если они есть)
    if last_message_id:
        await message.bot.delete_message(message.chat.id, last_message_id)
    if last_photo_id:
        await message.bot.delete_message(message.chat.id, last_photo_id)
    
    new_des_profile = message.text.strip()
    
    if len(new_des_profile) > 70:
        msg = await message.answer("Слишком много слов(")
        await state.update_data(last_message_id=msg.message_id)
    else:
        existing_description = await rq.add_profile_description(message.from_user.id, new_des_profile)
        
        if existing_description and existing_description != True:
            msg = await message.answer(f"У тебя уже есть описание профиля:\n\n<b>{existing_description}</b>", parse_mode="HTML")
        else:
            msg = await message.answer(f"✅ Успешно добавил в базу твое описание профиля", parse_mode="HTML")
        
        await state.update_data(last_message_id=msg.message_id)
        
        # Отправляем текстовое сообщение
        msg = await message.answer(
            "<b>Теперь ты в разделе выбора стиля комментариев.</b>\n\n"
            "🔹 <b>Стиль Сета Година (Маркетинг и продажи)</b>\n"
            "Этот стиль идеально подходит для тех, кто хочет привлекать аудиторию и продавать через личный бренд. "
            "Минимум воды, четкое УТП (уникальное торговое предложение), призыв к действию.\n\n"
            "🔹 <b>Стиль Гая Кавасаки (Привлечение внимания)</b>\n"
            "Подходит для блогеров, инфлюенсеров, людей, которым важно удерживать внимание. "
            "Добавляем эмоции, немного провокации, задаем интригу.\n\n"
            "🔹 <b>Стиль Илона Маска (Экспертность и технологии)</b>\n"
            "Если твой канал про технологии, инвестиции или у тебя экспертный контент, лучше придерживаться этого стиля. "
            "Простые слова, но глубокий смысл, намек на будущее и инновации.\n\n"
            "📌 <i>Выбери стиль, который лучше всего подходит твоему каналу.</i>",
            parse_mode="HTML",
            reply_markup=kb.style()
        )
        
        await state.update_data(last_message_id=msg.message_id)
        await state.clear()
        

@router.callback_query(F.data.startswith("go_style")) # Обработчик начала ввода каналов
async def com_start(callback: CallbackQuery, state: FSMContext):
    # Удаляем предыдущее сообщение
    await callback.message.delete()
    
    # Отправляем новое сообщение
    msg = await callback.message.answer(
        "✅ <b>Отлично!</b>\n\n"
        " Добавил Ваш стиль в базу данных",
        parse_mode="HTML"
    )
    await state.update_data(last_message_id=msg.message_id)
    
    msg = await callback.message.answer(
        f'Здесь Вам нужно ввести ссылки на каналы, в которых будут мониториться посты. \n\n'
        f'Введи ссылки на каналы в виде "t.me/название_канала" без кавычек.\n'
        f'Ты можешь ввести до 5 каналов.\n\n'
        f'<i>Если ты закончил, нажми кнопку "Достаточно".</i>',
        reply_markup=kb.neiro_chanels(), parse_mode="HTML"
    )
    await state.update_data(last_message_id=msg.message_id)
    await state.set_state(Step.add_chanels)


async def delete_message_safe(message: Message, message_id: int):

    try:
        await message.bot.delete_message(message.chat.id, message_id)
    except TelegramBadRequest as e:
        # Если сообщение уже удалено или недоступно, игнорируем ошибку
        if "message to delete not found" in str(e):
            print(f"Сообщение {message_id} уже удалено или недоступно.")
        else:
            raise e  # Если ошибка другая, пробрасываем её дальше

# Обработчик ввода каналов
@router.callback_query(F.data.startswith("add_chanels"))
async def handle_add_channels_callback(callback: CallbackQuery, state: FSMContext):
    # Обработка нажатия на кнопку
    await callback.answer()  # Подтверждаем нажатие на кнопку
    await callback.message.answer("Введите ссылки на каналы, разделяя их пробелами.")
    await state.set_state(Step.add_chanels)  # Устанавливаем состояние для ввода каналов


@router.message(Step.add_chanels)
async def com_start(message: Message, state: FSMContext):
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    
    # Удаляем предыдущее сообщение (если оно существует)
    if last_message_id:
        await delete_message_safe(message, last_message_id)
    
    user = await rq.get_user_data(message.from_user.id)
    max_count = await rq.get_sub_max(message.from_user.id)
    current_count = await rq.count_channels_for_user(message.from_user.id)
    remaining = max_count - current_count
    text = message.text.strip().lower()

    # Если пользователь нажал "Достаточно"
    if text == "достаточно":
        if current_count == 0:
            msg = await message.answer("Ты должен ввести хотя бы один канал перед тем, как нажать 'Достаточно'.")
            await state.update_data(last_message_id=msg.message_id)
            return
        else:
            await state.set_state(Step.all_ready)
            await all_ready(message, state)  # Переходим к финальному шагу
            return

    # Разделение введённых каналов
    channels = text.split()

    added_channels = 0
    for channel in channels:
        # Проверка формата ссылки
        if not channel.startswith("t.me/"):
            msg = await message.answer("Ссылка должна начинаться с t.me/ (например, t.me/название_канала). Попробуй снова.", reply_markup=kb.neiro_chanels())
            await state.update_data(last_message_id=msg.message_id)
            return

        # Проверка длины ссылки
        if len(channel) > 35:
            msg = await message.answer("Ссылка не должна превышать 35 символов. Попробуй снова.", reply_markup=kb.neiro_chanels())
            await state.update_data(last_message_id=msg.message_id)
            return

        # Добавление канала, если осталось место
        if remaining > 0:
            added = await rq.add_chanels(message.from_user.id, channel)
            if added:
                remaining -= 1
                added_channels += 1
            else:
                msg = await message.answer(f"Канал {channel} уже добавлен. Введи другой.", reply_markup=kb.neiro_chanels())
                await state.update_data(last_message_id=msg.message_id)
        else:
            break

    # Ответ пользователю
    if added_channels > 0:
        msg = await message.answer(
            f'✅ Ссылки сохранены! Осталось ещё {remaining} каналов.\n'
            f'Отправь ещё каналы или нажми "Достаточно".', reply_markup=kb.neiro_chanels()
        )
    else:
        msg = await message.answer(
            "Ты не добавил новые каналы. Попробуй снова или нажми 'Достаточно'.", reply_markup=kb.neiro_chanels()
        )
    await state.update_data(last_message_id=msg.message_id)

    # Если лимит каналов достигнут
    if remaining == 0:
        await state.set_state(Step.all_ready)
        await all_ready(message, state)  # Переходим к финальному шагу


# Обработчик завершения ввода каналов
@router.message(Step.all_ready)
async def all_ready(message: Message, state: FSMContext):
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    
    # Удаляем предыдущее сообщение (если оно существует)
    if last_message_id:
        await delete_message_safe(message, last_message_id)
    
    # Получаем данные пользователя
    user_data = await rq.get_user_data(message.from_user.id)
    channel_link = user_data.link
    channel_description = user_data.my_chanel_description
    profile_description = user_data.my_profile_description
    channels = await rq.get_chanels(message.from_user.id)
    # Анимация "загрузки"
    msg = await message.answer("<i>🔄 Подключаюсь к базе...</i>", parse_mode="HTML")
    await asyncio.sleep(1)

    await msg.edit_text("<i>🔗 Добавляю ссылку на канал...</i>", parse_mode="HTML")
    await asyncio.sleep(0.6)

    await msg.edit_text("<i>📝 Вставляю описание канала...</i>", parse_mode="HTML")
    await asyncio.sleep(0.4)

    await msg.edit_text("<i>👤 Вставляю описание профиля...</i>", parse_mode="HTML")
    await asyncio.sleep(0.3)

    await msg.edit_text("<i>📢 Переписываю каналы для мониторинга...</i>", parse_mode="HTML")
    await asyncio.sleep(0.5)

    await msg.edit_text("<i>🤖 Формирую финальный профиль...</i>", parse_mode="HTML")
    await asyncio.sleep(1.2)

        # Формируем красивое сообщение с эмодзи и отступами
    await msg.edit_text(
        f"<b>🚀 {message.from_user.first_name}, Ваш профиль готов ✅</b>\n\n"
        f"В данном разделе вы можете его редактировать.\n\n"
        f'Если всё отлично, продолжаем! Нажимайте ""Далее ▶️".',
        parse_mode="HTML",  # Указываем parse_mode один раз
        reply_markup=kb.main_keyboard_2(message.from_user.id)  # другая клавиатура
    )
    await state.clear()
   
    
@router.callback_query(F.data.startswith("next"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    # Удаляем предыдущее сообщение (если оно существует)
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    if last_message_id:
        await delete_message_safe(callback.message, last_message_id)

    # Отправляем новое сообщение
    msg = await callback.message.answer(
        "<b>Далее Вам нужно настроить то, как будут оставляться комментарии.</b>\n\n"
        "Выберите период, сколько бот будет ждать после выхода поста, прежде чем оставить комментарий.\n\n"
        "<i>Рекомендация: не меньше чем 200 секунд</i>",
        parse_mode="HTML",
        reply_markup=kb.period_com()
    )
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения
    await state.set_state(Step.period_com)
    
@router.message(Step.period_com)
async def all_ready(message: Message, state: FSMContext):
    # Удаляем предыдущее сообщение (если оно существует)
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    if last_message_id:
        await delete_message_safe(message, last_message_id)

    # Отправляем новое сообщение
    msg = await message.answer("Период записан ✅")
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения

    msg = await message.answer(
        "Укажите, сколько постов подряд бот будет комментировать на одном канале за 1 день.\n\n"
        "<i>Рекомендация: не более 5</i>",
        parse_mode="HTML",
        reply_markup=kb.sleep_bot()
    )
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения
    await state.set_state(Step.sleep_bot)

@router.message(Step.sleep_bot)
async def all_ready(message: Message, state: FSMContext):
    # Удаляем предыдущее сообщение (если оно существует)
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    if last_message_id:
        await delete_message_safe(message, last_message_id)

    # Отправляем новое сообщение
    msg = await message.answer("Посты записаны ✅")
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения

    msg = await message.answer(
        "Укажите, на сколько бот уйдет в сон после 50 комментариев.\n\n"
        "<i>Рекомендация: по опыту не менее чем на 180 минут</i>",
        parse_mode="HTML",
        reply_markup=kb.sleep_sleep()
    )
    await state.update_data(last_message_id=msg.message_id)  # Сохраняем ID сообщения
    await state.set_state(Step.launch_bot)
    msg = await message.answer(
        "Отлично! Все готово!\n\n"
        "<i>Жмите скомпелировать бота и возвращайтесь в главное меню для запуска нейрокомментинга!</i>",
        parse_mode="HTML",
        reply_markup=kb.compile()
    )



    

    
    
    
    
@router.message(Step.launch_bot)
async def all_ready(message: Message, state: FSMContext):
    # Удаляем предыдущее сообщение (если оно существует)
    data = await state.get_data()
    last_message_id = data.get("last_message_id")
    if last_message_id:
        await delete_message_safe(message, last_message_id)

    # Отправляем новое сообщение с анимацией
    msg = await message.answer("<i>🔄 Подключаюсь к базе...</i>", parse_mode="HTML")
    await asyncio.sleep(1)

    await msg.edit_text("<i>🔗 Добавляю ссылку на канал...</i>", parse_mode="HTML")
    await asyncio.sleep(0.6)

    await msg.edit_text("<i>📝 Вставляю описание...</i>", parse_mode="HTML")
    await asyncio.sleep(0.4)

    await msg.edit_text("<i>📢 Переписываю каналы...</i>", parse_mode="HTML")
    await asyncio.sleep(0.5)

    await msg.edit_text("<i>👤 Вставляю описание профиля...</i>", parse_mode="HTML")
    await asyncio.sleep(0.3)

    await msg.edit_text("<i>🤖 Формирую промт...</i>", parse_mode="HTML")
    await asyncio.sleep(1.2)
        
    await msg.edit_text(
        f"<b>✅ Готово!</b>\n\n"
        f"🤖 <b>Сформировал вашего бота:</b> <a href='https://t.me/ksi_filina'>@ksi_filina</a>\n\n"
        f"🔍 Бот будет <b>анализировать каналы</b> и оставлять там комментарии от своего имени.\n"
        f"📌 В профиле будет указано <b>описание вашего канала</b> и <b>ссылка</b>, создавая видимость, что этот бот — владелец аккаунта.\n\n"
        f"⚡ <b>Перейдите в главное меню для запуска нейрокомментинга</b>",
        parse_mode="HTML",
        reply_markup=kb.main_button()
    )




    
    
#⁡⁢⁣⁢-----------------------------------------------------Подписка оплата---------------------------------------------------------⁡

    
@router.callback_query(F.data.startswith("all_ready_pay"))
async def com_start(callback: CallbackQuery):
    sub = await rq.get_sub(callback.from_user.id)
    if sub.id ==1:
        await callback.message.answer("У вас пробная подписка. Если вы оплатили, но все еще видете эту надпись, напиши в тех поддержку, сразу же решим", reply_markup=kb.main_button())
        return
    # Текущая дата
    current_date = datetime.now()
    # Дата окончания через 20 дней
    end_date = current_date + timedelta(days=sub.date_day)
   
    await rq.set_sub_data(callback.from_user.id, end_date)
    await callback.message.answer("Успешно!", reply_markup= kb.main_button())
    return
    
        

@router.callback_query(F.data.startswith("subscriptions"))
async def com_start(callback: CallbackQuery):
    user = await rq.get_user_data(callback.from_user.id)
    date_exit = user.date_sub
    sub = await rq.get_sub(callback.from_user.id)
    sub_id=sub.id
    if (sub_id !=1):
        subscription_days=sub.date_day
        max_channels = sub.max_chanels
        message_text = (
    "<b>✅ Подписка активирована!</b>\n\n"
    f"📅 <b>Дата окончания подписки:</b> {date_exit}\n"
    "📋 <b>Каталог подписок:</b>\n"
    f"🔢 <b>Макс. количество каналов для нейрокомментинга:</b> <code>{max_channels}</code>\n\n"
    "🚀 <b>Что дальше?</b>\n"
    "Ты можешь добавить каналы для нейрокомментинга. Как только ты достигнешь лимита, "
    "система автоматически остановит возможность добавления новых.\n\n"
    "✨ <b>Хотите продлить подписку или увеличить количество каналов?</b>\n"
    "Перейди в раздел <b>Каталог подписок 📋</b>, чтобы продлить подписку "
    "или увеличить лимит каналов для нейрокомментинга."
)


        await callback.message.answer(message_text, parse_mode="HTML", reply_markup=kb.main_button())

    else:
        await callback.message.edit_text(
    f"🎉 <b>Твоя пробная подписка активна!</b>\n\n\n"
    f"Ты получил возможность использовать сервис бесплатно в течение пробного периода.\n"
    "⏳ Если ты хочешь продолжить пользоваться всеми функциями, тебе нужно будет оформить полноценную подписку.\n"
    "Переходи в <b>Каталог подписок 📋</b> и выбери подходящий план.\n\n"
    
    "🔑 <b>Условия пробной подписки</b>:\n"
    f" - Ты можешь отправлять мне посты и я буду давать тебе примеры коментариев на них.\n"
    f" - Пробная подписка доступна только в течение <b>10 дней</b> с момента активации. После этого доступ будет ограничен.\n\n"
    
    "🔄 Если ты хочешь увеличить количество каналов или продлить подписку, переходи по ссылке <b>Каталог подписок 📋</b>.\n"
    "⏰ В случае истечения пробной подписки ты получишь уведомление о необходимости оформить полную подписку для продолжения работы с ботом.\n",
    parse_mode="HTML", reply_markup=kb.main_button())


@router.callback_query(F.data.startswith("by_subscriptions"))
async def com_start(callback: CallbackQuery):
    await callback.message.edit_text(
        "<b>🚀 Усильте охваты с нейрокомментингом!</b>\n\n"
        "💡 Хотите привлекать клиентов и выделяться среди конкурентов? Нейросеть сделает всё за вас!\n\n"
        "<b>🔥 <u>Тариф 'Начальное продвижение'</u> — попробуйте прямо сейчас!</b>\n"
        "💰 <b>1990₽</b> вместо <s>3990₽</s> за:\n"
        "✔ <b>14 каналов</b> на мониторинг\n"
        "✔ <b>20 дней</b> работы 24/7\n"
        "✔ Готовое решение без вложений в рекламу!\n\n"
        "<b>✅ Что вы получите?</b>\n"
        "🔹 <b>Максимальный охват</b>: Нейросеть будет комментировать публикации в 14 выбранных каналах.\n"
        "🔹 <b>Реальный результат</b>: Подписчики и клиенты найдут вас сами.\n"
        "🔹 <b>Быстрый эффект</b>: Уже в первые дни увидите рост интереса!\n\n"
        "<b>💥 Другие тарифы:</b>\n"
        "📌 <b>'Базовый'</b> — 20 каналов, 25 дней → 2490₽ <s>4990₽</s>\n"
        "📌 <b>'Про'</b> — 35 каналов, 30 дней → 3990₽ <s>6990₽</s>\n"
        "📌 <b>'Эксперт'</b> — 50 каналов, 60 дней → 6990₽ <s>13990₽</s>\n\n"
        "<b>⚡ Важно!</b> Сейчас тарифы в 2 раза дешевле из-за тестового периода. Любая покупка — доступ ко всем будущим обновлениям БЕСПЛАТНО!\n\n"
        "💬 <b>Готовы?</b> Жмите 'Купить подписку' и начните прямо сейчас!\n\n"
        "🔹 После подтверждения оплаты нажмите кнопку 'Админ подтвердил оплату'."
        , parse_mode="HTML", reply_markup=kb.get_subscription_keyboard()
    )

#⁡⁢⁣⁡⁢⁣⁢-------------------------------------------------------------------------------------------------------------------------------⁡



#----------------------------------------------------------------------------------------ПРОФИЛЬНЫЕ КОМАНДЫ-------------------------------------------------------------------------------------------------

@router.callback_query(F.data.startswith("add_link"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text("Введите ссылку на свой канал. В процессе нейрокомментинга люди будут переходить именно по ней" , reply_markup=kb.main_button())
    new_link = callback.message.text
    await state.set_state(Reg.waiting_add)


@router.message(Reg.waiting_add)
async def process_link(message: Message, state: FSMContext):
    """Обрабатывает введённую пользователем ссылку."""
    new_link = message.text


    # Проверяем, не превышает ли длина ссылки 25 символов
    if len(new_link) > 35:
        await message.answer("Ошибка! Ссылка не должна превышать 35 символов. Попробуйте снова.", reply_markup=kb.main_button())
        return
    
    
    # Проверяем, начинается ли ссылка с @
    if not new_link.startswith("t.me/"):
        await message.answer("Ошибка! Ссылка на канал должна начинаться с t.me/. Попробуйте снова.", reply_markup=kb.main_button())
        return

    

    succeful_add = await rq.add_link(message.from_user.id, new_link)

    if succeful_add:
        await message.answer("✅ Ваша ссылка успешно добавлена!", reply_markup=kb.main_button())
    else:
        await message.answer("⚠️ Данная ссылка уже была добавлена ранее.", reply_markup=kb.main_button())

    await state.clear()  # Очищаем состояние











#⁡⁢⁣⁢----------------------------------------------------------------Редактирование описания канала и профиля ----------------------------------------------⁡
@router.callback_query(F.data.startswith("description_chanel"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    user = await rq.get_user_data(callback.from_user.id)
    if user.my_chanel_description:
        await callback.message.edit_text(
            f"Краткое описание твоего канала: {user.my_chanel_description}",
            parse_mode="HTML",
            reply_markup=kb.edit_des_chanel()  # Клавиатура для редактирования
        )
    else:
        await callback.message.edit_text(
            "Добавь описание своего канала",
            reply_markup=kb.edit_des_chanel()  # Клавиатура для редактирования
        )

# Обработчик для начала редактирования описания
@router.callback_query(F.data.startswith("edit_chanel_description"))
async def edit_description_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "Введите новое описание вашего канала (не более 30 слов):")
    await state.set_state(EditChannelState.waiting_for_description)  # Устанавливаем состояние


# Обработчик для сохранения нового описания канала
@router.message(EditChannelState.waiting_for_description)
async def save_new_description(message: Message, state: FSMContext):
    new_description = message.text.strip()
    
    # Проверяем, что описание не превышает 30 слов
    if len(new_description.split()) > 30:
        await message.answer("Описание должно быть не более 30 слов. Попробуйте снова.")
        return
    
    # Сохраняем новое описание в базу данных
    await rq.update_chanel_description(message.from_user.id, new_description)
    
    # Очищаем состояние
    await state.clear()
    
    # Отправляем подтверждение
    await message.answer(
        f"✅ Описание канала успешно обновлено:\n\n{new_description}",
        reply_markup=kb.edit_des_chanel()  # Возвращаем клавиатуру для редактирования
    )
    
    
@router.callback_query(F.data.startswith("description_profile"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    user = await rq.get_user_data(callback.from_user.id)
    if user.my_profile_description:
        await callback.message.edit_text(
            f"Краткое описание для профиля нейробота: {user.my_chanel_description}",
            parse_mode="HTML",
            reply_markup=kb.edit_des_profile()  # Клавиатура для редактирования
        )
    else:
        await callback.message.edit_text(
            "Добавь описание для профиля нейробота до 70 символов + ссылка на ваш канал",
            reply_markup=kb.edit_des_profile()  # Клавиатура для редактирования
        )


@router.callback_query(F.data.startswith("edit_profile_description"))
async def edit_description_start(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "Введите новое описание для профиля нейробота")
    await state.set_state(EditChannelState.waiting_for_description)  # Устанавливаем состояние


# Обработчик для сохранения нового описания
@router.message(EditChannelState.waiting_for_description)
async def save_new_description(message: Message, state: FSMContext):
    new_description = message.text
    
    # Проверяем, что описание не превышает 30 слов
    if len(new_description) > 70:
        await message.answer("Описание должно быть не более 70 символов. Попробуйте снова.")
        return
    
    # Сохраняем новое описание в базу данных
    await rq.update_profile_description(message.from_user.id, new_description)
    
    # Очищаем состояние
    await state.clear()
    
    # Отправляем подтверждение
    await message.answer(
        f"✅ Описание канала успешно обновлено:\n\n{new_description}",
        reply_markup=kb.edit_des_chanel()  # Возвращаем клавиатуру для редактирования
    )
#⁡⁢⁣⁢---------------------------------------------------------------------------------------------------------------------------------------------------⁡









#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------














#----------------------------------------------------------------------------------------КАНАЛЬНЫЕ КОМАНДЫ-------------------------------------------------------------------------------------------------

@router.callback_query(F.data == "list_chanel")
async def com_start(callback: CallbackQuery):
    user = await rq.get_user_data(callback.from_user.id)
    
    await callback.message.edit_text("Твои каналы, выбери что бы удалить или изменить", reply_markup = await kb.inline_chanels(callback.from_user.id))



@router.callback_query(F.data.startswith("query_"))
async def com_start(callback: CallbackQuery):
    old_link = callback.data.replace("query_", "")
    await callback.message.edit_text('Выбери действие', reply_markup= kb.ed_or_del(old_link))



@router.callback_query(F.data.startswith("edit_chanel_"))
async def com_start(callback: CallbackQuery, state: FSMContext):
    old_link = callback.data.replace("edit_chanel_", "")
    await state.update_data(old_link=old_link)
    await state.set_state(EditChannelState.waiting_for_new_link)
    await callback.message.edit_text(f"Введите новую ссылку вместо канала: {old_link}")



@router.message(EditChannelState.waiting_for_new_link)
async def process_new_link(message: Message, state: FSMContext):
    data = await state.get_data()
    old_link = data.get("old_link")  # Получаем старый канал из состояния
    new_link = message.text  # Новая ссылка от пользователя
    
    if not new_link.startswith("t.me/"):  # Простейшая проверка на ссылку
        await message.answer("Пожалуйста, введите корректную ссылку (должна начинаться с t.me/)")
        return

    # Обновляем в БД
    await rq.update_channel(message.from_user.id, old_link, new_link)

    await message.answer(f"Канал обновлён: {old_link} → {new_link}")
    await state.clear()  # Очищаем состояние



@router.callback_query(F.data.startswith("delete_chanel_"))
async def com_start(callback: CallbackQuery):
    old_link = callback.data.replace("delete_chanel_", "")
    await rq.delete_channel(callback.from_user.id, old_link)
    await callback.message.edit_text(f"Удалил канал {old_link} из базы", reply_markup=kb.main_button() )







@router.callback_query(F.data.startswith("my_bot"))
async def com_start(callback: CallbackQuery):
    user = await rq.get_user_data(callback.from_user.id)
    sub = user.sub_id
    if sub ==1:
        await callback.answer("Извините, но для этого раздела нужна подписка (")
        return
    bot = await rq.get_bot_data(callback.from_user.id)
    await callback.message.edit_text(f"Вот ссылка на вашего собранного бота от имени которого будут  оставлться коментарии: {bot.link_bot}")
        
        
    
        
    # Обработчик команды /add_suba
@router.message(Command('add_suba'))
async def get_chanels_other(message: Message, state: FSMContext):
    await message.answer("Давай твой tg_id", reply_markup=kb.main_button())
    await state.set_state(EditChannelState.waiting_tg_id)

# Обработчик для состояния "waiting_tg_id"
@router.message(EditChannelState.waiting_tg_id)
async def process_channel_link(message: Message, state: FSMContext):
    tg_id = message.text.strip()  # Получаем tg_id из введенного текста и убираем пробелы по краям
    if tg_id == "назад":
        await state.clear()
        await message.answer("Возвращаемся в главное меню.", reply_markup=kb.main_button())
        return

    if not tg_id.isdigit():  # Проверка на то, что tg_id состоит только из цифр
        await message.answer("Ты ввел некорректный tg_id. Попробуй снова.")
        return

    tg_id = int(tg_id)  # Преобразуем tg_id в число для дальнейшего использования

    # Сохраняем tg_id в состояние
    await state.update_data(tg_id=tg_id)

    # Получаем каналы по tg_id
    chanels = await rq.get_chanels(tg_id)

    if not chanels:
        await message.answer("Не удалось найти каналы для данного tg_id.")
    else:
        for chanel in chanels:
            await message.answer(chanel)

    # Очистка состояния после выполнения
    await state.clear()

@router.callback_query(F.data.startswith("feedback"))
async def com_start(callback: CallbackQuery):
    await callback.message.answer("Вы попали в раздел с отзывами. Данный раздел не очень велик, так как бот , напоминаю, относительно новый, его жизненный цикл всего месяц на данный момент. Как будет набираться +- 5 отзывов буду сразу пополнять ими данный раздел. Что бы ознакомиться с ними, нажмите 'Показать отзывы'. Напоминаю, что за каждый отзыв я добавляю 14 дней к подписке плюсом)",  reply_markup=kb.feedback())
    
@router.callback_query(F.data.startswith("otziv"))
async def com_start(callback: CallbackQuery):
    folder_path = os.path.join("feedback")  # Путь к папке с фото
    files = sorted(os.listdir(folder_path))  # Получаем список файлов
    
    images = [f for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp'))]  # Фильтруем изображения
    
    if not images:
        await callback.answer("❌ Нет фото в папке 'feedback'", show_alert=True)
        return
    
    await callback.message.answer("📷 Загружаю отзывы...")
    
    for img in images:
        file_path = os.path.join(folder_path, img)
        photo = FSInputFile(file_path)
        await callback.message.answer_photo(photo)
        await asyncio.sleep(1)  # Задержка в 1 секунду